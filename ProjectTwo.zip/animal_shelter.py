# Author: Kenneth J Gollaher
# CS340: PY for Project Two
# Date: 17APR2022

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
   # """ CRUD operations for Animal collection in MongoDB """

    def __init__(self,username,password):
        # init to connect to mongodb without authentication 
        self.client = MongoClient('mongodb://localhost:35673')
        # init connect to mongod with authentication
        #self.client = MongoClient('mongodb://%s:%s@localhost:35673/?authMechanism=DEFAULT&authSource=AAC'%(username,password)
        self.database = self.client['AAC']

# Method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data)  # insert data if data is not none
            return True
        else:
            raise Exception("Unable to Save Data, Empty Data Parameter.")

# Method to implement the R in CRUD. 
    def read_all(self,data):
        # return a cursor which a pointer to a list of results(Documents)
        cursor = self.database.animals.find(data, {'_id':False})
        return cursor
    
    def read(self,data):
        return self.database.animals.find_one(data) ## returns only one document
        
# Method to implement U in CRUD
    def update(self,data,new_data):
        if data is not None:
        
            # return if records updated is > than zero
            result = self.database.animals.update_one(data,new_data)
            return result.matched_count>0
        
        else:
            updateException = "No Records to Update."
            raise Exception(updateException)
            
# Method to implement D in CRUD
    def delete(self,data):
        if data is not None:
        
            #return if records deleted is > than zero
            result = self.database.animals.delete_one(data)
            return result.deleted_count>0
        
        else:
            deleteException = "No Records to Delete."
            raise Exception("deleteException")